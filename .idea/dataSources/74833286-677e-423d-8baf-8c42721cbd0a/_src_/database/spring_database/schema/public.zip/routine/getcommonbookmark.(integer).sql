create function getcommonbookmark(integer) returns integer
LANGUAGE SQL
AS $$
SELECT cast(round(cast(SUM(mark) AS DOUBLE PRECISION)/COUNT(user_id)) AS INTEGER)
FROM books_users_votes
WHERE book_id = $1;
$$;
