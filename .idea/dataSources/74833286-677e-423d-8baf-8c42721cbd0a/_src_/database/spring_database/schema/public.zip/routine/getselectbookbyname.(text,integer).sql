create function getselectbookbyname(text, integer) returns SETOF books
LANGUAGE SQL
AS $$
SELECT *
FROM spring_database.public.books
WHERE name ~* ('(\A' || $1 || '.*)')
ORDER BY name DESC LIMIT 5 OFFSET $2*5 ;
$$;
