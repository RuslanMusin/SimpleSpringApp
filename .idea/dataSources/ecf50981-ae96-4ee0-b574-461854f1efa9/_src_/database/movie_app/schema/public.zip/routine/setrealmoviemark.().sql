create function setrealmoviemark() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
   _movie_id integer := NEW.movie_id;
BEGIN

    UPDATE movie_app.public.movies SET mark = getCommonMovieMark(_movie_id)
    WHERE movies.movie_id = _movie_id;

    RETURN NULL;
END
$$;
