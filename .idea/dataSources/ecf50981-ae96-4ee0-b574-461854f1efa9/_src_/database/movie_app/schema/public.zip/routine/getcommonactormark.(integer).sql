create function getcommonactormark(integer) returns integer
LANGUAGE SQL
AS $$
SELECT cast(round(cast(SUM(mark) AS DOUBLE PRECISION)/COUNT(user_id)) AS INTEGER)
    FROM actors_users_votes_bind
    WHERE actor_id = $1;
$$;
