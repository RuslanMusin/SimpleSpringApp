create function getusermoviemark(integer, integer) returns integer
LANGUAGE SQL
AS $$
SELECT mark
    FROM movies_users_votes_bind
    WHERE  movie_id = $1 AND user_id = $2;
$$;
