create function getuseractormark(integer, integer) returns integer
LANGUAGE SQL
AS $$
SELECT mark
    FROM actors_users_votes_bind
    WHERE  actor_id = $1 AND user_id = $2;
$$;
