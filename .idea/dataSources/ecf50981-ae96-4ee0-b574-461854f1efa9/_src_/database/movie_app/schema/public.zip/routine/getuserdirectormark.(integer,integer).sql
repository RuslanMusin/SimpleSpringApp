create function getuserdirectormark(integer, integer) returns integer
LANGUAGE SQL
AS $$
SELECT mark
    FROM directors_users_votes_bind
    WHERE  director_id = $1 AND user_id = $2;
$$;
