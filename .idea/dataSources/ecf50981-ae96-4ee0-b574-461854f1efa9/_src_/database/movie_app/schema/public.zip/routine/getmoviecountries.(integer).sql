create function getmoviecountries(integer) returns SETOF countries
LANGUAGE SQL
AS $$
SELECT countries.country_id,countries.name
    FROM countries
    INNER JOIN movies_countries_bind ON countries.country_id = movies_countries_bind.country_id
    WHERE movies_countries_bind.movie_id = $1;
$$;
