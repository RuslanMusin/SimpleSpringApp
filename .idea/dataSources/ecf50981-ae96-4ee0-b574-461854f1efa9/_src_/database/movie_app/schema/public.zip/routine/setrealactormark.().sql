create function setrealactormark() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
   _actor_id integer := NEW.actor_id;
BEGIN

    UPDATE movie_app.public.actors SET mark = getCommonActorMark(_actor_id)
    WHERE actors.actor_id = _actor_id;

    RETURN NULL;
END
$$;
