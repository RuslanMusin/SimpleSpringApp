create function getmoviegenres(integer) returns SETOF genres
LANGUAGE SQL
AS $$
SELECT genres.genre_id,genres.name
    FROM genres
    INNER JOIN movies_genres_bind ON genres.genre_id = movies_genres_bind.genre_id
    WHERE movies_genres_bind.movie_id = $1;
$$;
