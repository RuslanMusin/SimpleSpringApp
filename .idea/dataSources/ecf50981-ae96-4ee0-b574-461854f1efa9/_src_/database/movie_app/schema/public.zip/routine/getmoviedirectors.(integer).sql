create function getmoviedirectors(integer) returns SETOF directors
LANGUAGE SQL
AS $$
SELECT directors.director_id,directors.name,directors.surname,directors.birthday,
        directors.motherland,directors.photo,directors.mark,directors.description
    FROM directors
    INNER JOIN movies_directors_bind ON directors.director_id = movies_directors_bind.director_id
    WHERE movies_directors_bind.movie_id = $1;
$$;
