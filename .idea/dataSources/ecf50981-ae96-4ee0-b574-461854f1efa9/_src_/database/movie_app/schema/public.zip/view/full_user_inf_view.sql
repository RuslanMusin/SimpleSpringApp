CREATE VIEW full_user_inf_view AS SELECT users.user_id,
    users.email,
    users.username,
    users.gender,
    users.country_id,
    users.user_right,
    users.cookie_id,
    countries.name,
    rights.right_name
   FROM ((users
     JOIN countries ON ((users.country_id = countries.country_id)))
     JOIN rights ON ((users.user_right = rights.right_id)));
