create function getselectdirectorbyname(text, text, integer) returns SETOF directors
LANGUAGE SQL
AS $$
SELECT *
    FROM directors
    WHERE (surname ~* ('(\A' || $2 || '.*|\A' || $1 || '.*)')) OR (name ~* ('(\A' || $1 || '.*|\A' || $2 || '.*)'))
    ORDER BY name DESC,surname DESC LIMIT 5 OFFSET $3*5 ;
$$;
