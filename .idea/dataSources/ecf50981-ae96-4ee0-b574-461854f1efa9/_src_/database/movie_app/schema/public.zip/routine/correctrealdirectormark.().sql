create function correctrealdirectormark() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
   _director_id integer := OLD.director_id;
BEGIN

    UPDATE movie_app.public.directors SET mark = getCommonDirectorMark(_director_id)
    WHERE directors.director_id = _director_id;

    RETURN NULL;
END
$$;
