create function getselectmoviebyname(text, integer) returns SETOF movies
LANGUAGE SQL
AS $$
SELECT *
    FROM movie_app.public.movies
    WHERE name ~* ('(\A' || $1 || '.*)')
    ORDER BY name DESC LIMIT 5 OFFSET $2*5 ;
$$;
